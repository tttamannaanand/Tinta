<div align="center">

# Tinta

**Type a feeling. Get a color palette, a matching abstract art piece, a real playable Spotify tracklist, and a photo moodboard — all pulled from the same palette.**

</div>

## What this actually does

*Tinta* — Spanish/Italian for "ink" or "tint." Type a mood, get the color it's dyed in.

There's no machine-learning sentiment model here — the "understanding" is a hand-curated lexicon (`site/js/lexicon.js`) mapping ~90 common mood/imagery words (*golden*, *rain*, *melancholy*, *neon*...) to a color anchor and a music genre. Same input text always produces the same output — it's a seeded hash, not randomness, so a mood you liked is reproducible.

| Output | How |
|---|---|
| **Palette** | Matched words' HSL anchors are circular-mean-blended into 5 tonal colors |
| **Generative art** | Abstract SVG circles, seeded from the input text, colored from the palette |
| **Tracklist** | Matched words' genre tags → real Spotify search → embedded playable widgets |
| **Moodboard** | Matched words → Unsplash photo search, properly credited |

## Two honest architecture notes

**Spotify:** their `/recommendations` and `/audio-features` endpoints (the ones that would've let this match songs by actual mood *audio* data — valence, energy) were deprecated for new developer apps in November 2024. On top of that, Spotify overhauled Developer Mode again in February–March 2026: the app owner's account now needs an active Premium subscription, apps are capped at one Client ID per developer and a small number of authorized users, and Spotify signaled they're moving away from client-credentials for some metadata endpoints. Plain track search has held up in community reports so far, but if this starts returning errors, that's the first thing to check — it's a fast-moving policy area.

**Why there's a serverless function at all:** Spotify's search requires a client-credentials token exchange, which needs a secret that can never sit in frontend JS. `api/spotify-search.js` does that exchange server-side and only ever returns track results to the browser. Unsplash's free tier, by contrast, is designed for direct client-side calls (its access key is a rate limiter, not a real secret) — the separate Unsplash *Secret Key* it also gives you is for OAuth flows and isn't used here.

## Setup

```bash
git clone https://github.com/<your-username>/tinta.git
cd tinta
npm install -g vercel   # if you don't have it

cp .env.example .env
# fill in SPOTIFY_CLIENT_ID and SPOTIFY_CLIENT_SECRET
# get both free at https://developer.spotify.com/dashboard
# (the owning account needs Spotify Premium as of the 2026 policy change)
```

Add your Unsplash access key in `site/js/config.js` (also free, instant: https://unsplash.com/developers — use the Access Key, not the Secret Key).

```bash
vercel dev
# → open http://localhost:3000
```

Plain `python3 -m http.server` inside `site/` will *not* work for the Spotify tracklist — that needs the `/api` route, which only `vercel dev` or a real Vercel deployment provides. The palette, art, and (if you've added an Unsplash key) moodboard all work fine as pure static files, though.

## Deploying

Push to GitHub, import the repo on [Vercel](https://vercel.com), then in the project's **Settings → Environment Variables** add `SPOTIFY_CLIENT_ID` and `SPOTIFY_CLIENT_SECRET`. Deploy — `vercel.json` points static output at `site/`, and Vercel auto-detects `api/spotify-search.js` as a serverless function.

**Never commit your `.env` file** — `.gitignore` already excludes it, but double check before your first push if you ever copy files around manually.

## Extending this

- The lexicon is deliberately small and easy to read — add your own words/anchors to `MOOD_LEXICON` in `site/js/lexicon.js`
- Swap the circle-based generative art for something fancier (noise fields, gradients-as-shapes) in `renderArt()` in `site/js/palette.js`
- Add a "save this mood" feature using `localStorage`, or build a personal mood history

## Credit

Track playback via [Spotify](https://open.spotify.com)'s embed player. Photos via [Unsplash](https://unsplash.com), credited per-image as their API terms require.
